# Quad ADSR front panel

Low cost pcb front panel option

![](./pics/front_panel.png?raw=true "front panel")