# This subdirectory contains documents for buiding the hardware for the system.

- ### All schematic capture and pcb layout is done using kicad.

- ### `main_pcb` contains everything you need to build and/or modify the main circuit board. 

- ### `front_panel` contains documents for making a low cost pcb front panel.
