
int main(void)
{
    while (1)
    {
        // empty while loop, everything happens in the interrupt service routines
    }

    // never reached
    return 0;
}
